package endpoint;

import javax.jws.WebService;

@WebService
public interface Mathematics {
	public int multiply(int a, int b); 
}

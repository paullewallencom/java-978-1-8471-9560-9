package ejb30.entity;

public enum Gender { MALE, FEMALE }


package ejb30.client;

import java.util.*;
import javax.naming.*;
import ejb30.session.*;
import javax.ejb.EJB;

public class Client {

    public static void main(String args[]) throws Exception {
 
       InitialContext ctx = new InitialContext();
       
       ShoppingCart shoppingCart = (ShoppingCart) ctx.lookup("ShoppingCart#ejb30.session.ShoppingCart");

       shoppingCart.addItem("Bread");
       shoppingCart.addItem("Milk");
       Thread.sleep(59000);
       shoppingCart.addItem("Tea");

       System.out.println("Contents of your cart are:");
       Collection<String> items = shoppingCart.getItems();
       for (String item : items) {
            System.out.println(item);
       }

       shoppingCart.finished();
    }

}



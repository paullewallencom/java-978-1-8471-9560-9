package ejb30.client;

import javax.naming.*;
import ejb30.session.*;
import javax.ejb.EJB;

public class Client {
     
    public static void main(String args[]) throws Exception {

       InitialContext ctx = new InitialContext();
       TimeService timeService = (TimeService) ctx.lookup("TimeService#ejb30.session.TimeService");
 
       String time = timeService.getTime();
       System.out.println("Time is: " + time);
    }

}

package ejb30.client;
import javax.naming.Context;
import javax.naming.InitialContext;
import ejb30.session.*;
import ejb30.entity.Account; 
import java.util.*;
import javax.ejb.EJB;

public class BankClient {
    
    public static void main(String[] args) {

        try {
            InitialContext ctx = new InitialContext();
            BankService bank = (BankService) ctx.lookup("BankService#ejb30.session.BankService");

            bank.createAccounts();

            try
            {
              Thread.sleep(15000);
            } catch (Exception e) {
            }
 
            List<Account> accounts = bank.findAllAccounts();
            for (Account account : accounts) {
               System.out.println(account);
            } 
            
        } catch (Throwable ex) {
            ex.printStackTrace();
        }

    }

}

